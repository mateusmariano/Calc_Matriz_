﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class calculos
    {

        #region Soma

        public static float[,] Somar(float[,] Matriz1, float[,] Matriz2)
        {
            float[,] matrizCalculada = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            for (int x = 0; x < matrizCalculada.GetLength(0); x++)
            {
                for (int y = 0; y < matrizCalculada.GetLength(1); y++)
                {
                    matrizCalculada[x, y] = Matriz1[x, y] += Matriz2[x, y];
                }
            }
            return matrizCalculada;
        }
        #endregion
        #region Subtração
        public static float[,] Subtrair(float[,] Matriz1, float[,] Matriz2)
        {
            float[,] matrizCalculada = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            for (int x = 0; x < matrizCalculada.GetLength(0); x++)
            {
                for (int y = 0; y < matrizCalculada.GetLength(1); y++)
                {
                    matrizCalculada[x, y] = Matriz1[x, y] -= Matriz2[x, y];
                }
            }
            return matrizCalculada;
        }
        #endregion
        #region Multiplicação
        public static float[,] Multiplicar(float[,] Matriz1, float[,] Matriz2)
        {
            float[,] matrizCalculada = new float[Matriz1.GetLength(0), Matriz2.GetLength(1)];
            for (int x = 0; x < matrizCalculada.GetLength(0); x++)
            {
                for (int y = 0; y < matrizCalculada.GetLength(1); y++)
                {
                    for (int n = 0; n < Matriz2.GetLength(0); n++)
                    {
                        string i = "" + Matriz1[x, n];
                        matrizCalculada[x, y] += Matriz1[x, n] * Matriz2[n, y];
                    }
                }
            }
            return matrizCalculada;
        }
        #endregion
        #region Oposta
        public static float[,] Oposta(float[,] matriz)
        {
            float[,] matrizOposta = new float[matriz.GetLength(0), matriz.GetLength(1)];
            for (int x = 0; x < matrizOposta.GetLength(0); x++){
                for (int y = 0; y < matrizOposta.GetLength(1); y++){
                    matrizOposta[x, y] += matriz[x, y] * -1;
                }
            }
            return matrizOposta;
        }
        #endregion
        #region Tranposta
        public static float[,] Transposta(float[,] matriz) {

            float[,] matrizTransposta = new float[matriz.GetLength(1), matriz.GetLength(0)];
            for (int x = 0; x < matrizTransposta.GetLength(0);x ++) {
                for (int y = 0; y < matrizTransposta.GetLength(1); y ++) {
                    matrizTransposta[x, y] += matriz[y, x];
                }
            }
            return matrizTransposta;
        }
        #endregion
        #region Determinates
        #region Det 2x2
        public static float Det2(float[,] matriz) {
            float principal = 1;
            float secundaria = 1;
            float detfinal= 0;

            for (int x = 0; x < matriz.GetLength(0); x ++) {
                for (int y = 0; y < matriz.GetLength(1); y++) {
                    if (x == y) {
                        principal *= matriz[x, y];
                    }
                }
            }
            for (int x = 0; x < matriz.GetLength(0); x++)
            {
                for (int y = 0; y < matriz.GetLength(1); y++)
                {
                    if (x != y)
                    {
                        secundaria *= matriz[x, y];
                    }
                }
            }
            detfinal = principal - secundaria;
            return detfinal;

        }
        #endregion
        #region Det1 3x3
        public static float determinantes3x3(float[,] matriz)
        {
            float diagonalPrincipal = 0;
            float diagonalSecundaria = 0;
            float determinanteFinal = 0;
            int sizeSarrus = (((matriz.GetLength(0) * matriz.GetLength(1)) * 2) / 3) - 1;
            float[,] Sarrus = new float[matriz.GetLength(0), sizeSarrus];
            for (int x = 0; x < Sarrus.GetLength(0); x++)
            {
                for (int y = 0; y < Sarrus.GetLength(1); y++)
                {
                    if (y > matriz.GetLength(0) - 1)
                    {
                        Sarrus[x, y] += matriz[x, y - matriz.GetLength(0)];
                    }
                    else
                    {
                        Sarrus[x, y] += matriz[x, y];
                    }
                }
            }

            int voltas = 3;
            for (int i = 0; i < voltas; i++)
            {
                int numero = i;
                float mDiagonal = 1;
                for (int x = 0; x < Sarrus.GetLength(0); x++)
                {
                    for (int y = 0; y < Sarrus.GetLength(1); y++)
                    {
                        if (x == y)
                        {
                            string z = "" + Sarrus[x, y + numero];
                            mDiagonal *= Sarrus[x, y + numero];
                        }
                    }
                }
                diagonalPrincipal += mDiagonal;
            }

            for (int i = 0; i < voltas; i++)
            {
                int numero = i;
                float mDiagonal = 1;
                for (int x = 0; x < Sarrus.GetLength(0); x++)
                {
                    for (int y = Sarrus.GetLength(1) - 1; y > 0; y--)
                    {
                        if (x == (Sarrus.GetLength(1) - 1) - y)
                        {
                            string z = "" + Sarrus[x, y - numero];
                            mDiagonal *= Sarrus[x, y - numero];
                        }
                    }
                }
                diagonalSecundaria += mDiagonal;
            }
            determinanteFinal = diagonalPrincipal - diagonalSecundaria;
            return determinanteFinal;
         }
        #endregion
        #endregion
        #region Escalar
        public static float[,] Escalar(float[,] matriz,int valordoescalar) {
            float[,] matrizResultante = new float[matriz.GetLongLength(0), matriz.GetLongLength(1)];
            for (int x = 0; x < matrizResultante.GetLongLength(0); x++)
            {
                for (int y = 0; y < matrizResultante.GetLongLength(1); y++)
                {
                    matrizResultante[x, y] = matriz[x, y] *= valordoescalar;
                }
            }
            return matrizResultante;
        }
        #endregion


    }
}
