﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        private TextBox[,] Matriz1;
        private TextBox[,] Matriz2;
        private TextBox[,] MatrizCalculada;
        private TextBox[,] escalar;

        int linha1, coluna1;
        int linha2, coluna2;

        private float determinante;
        private float valorescalar;

        public Form1()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox3_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void button20_Click(object sender, EventArgs e)
        {
            #region Resquistos
            //////////////requisitos//////////////////
            if (!int.TryParse(ML2.Text, out linha2))
            {
                MessageBox.Show("Coloque números , por favor");
                return;
            }
            if (!int.TryParse(MC2.Text, out coluna2))
            {
                MessageBox.Show("Coloque números , por favor");
                return;
            }
            if (linha2 > 10 || linha2 <= 0 || coluna2 > 10 || coluna2 <= 0)
            {
                MessageBox.Show("No máximo uma matriz 10 x 10 , com valores maiores do que 0");
                return;
            }
            //////////////fecha_requisitos//////////////////
            #endregion
            #region Gerar_matriz
            GM2.Controls.Clear();
            Matriz2 = new TextBox[linha2, coluna2];


            int TamanhoText = GM2.Width / coluna2;

            for (int x = 0; x < Matriz2.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz2.GetLength(1); y++)
                {
                    Matriz2[x, y] = new TextBox();
                    Matriz2[x, y].Text = "";
                    Matriz2[x, y].Top = (x * Matriz2[x, y].Height) + 20;
                    Matriz2[x, y].Left = y * TamanhoText + 6;
                    Matriz2[x, y].Width = TamanhoText;
                    GM2.Controls.Add(Matriz2[x, y]);
                }
            }
            #endregion

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void button19_Click(object sender, EventArgs e)
        {
            #region Requisitos
            //////////////requisitos//////////////////
            if (!int.TryParse(ML1.Text, out linha1))
            {
                MessageBox.Show("Coloque números , por favor");
                return;
            }
            if (!int.TryParse(MC1.Text, out coluna1))
            {
                MessageBox.Show("Coloque números , por favor");
                return;
            }
            if (linha1 > 10 || linha1 <= 0 || coluna1 > 10 || coluna1 <= 0)
            {
                MessageBox.Show("No máximo uma matriz 10 x 10 , com valores maiores do que 0");
                return;
            }
            //////////////fecha_requisitos//////////////////
            #endregion Requisitos
            #region Gerar_matriz
            GM1.Controls.Clear();
            Matriz1 = new TextBox[linha1, coluna1];



            int TamanhoText = GM1.Width / coluna1;

            for (int x = 0; x < Matriz1.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz1.GetLength(1); y++)
                {
                    Matriz1[x, y] = new TextBox();
                    Matriz1[x, y].Text = "";
                    Matriz1[x, y].Top = (x * Matriz1[x, y].Height) + 20;
                    Matriz1[x, y].Left = y * TamanhoText + 6;
                    Matriz1[x, y].Width = TamanhoText;
                    GM1.Controls.Add(Matriz1[x, y]);
                }
            }
            #endregion 
        }

        private void button4_Click(object sender, EventArgs e)
        {
            #region Requisitos
            //////////////requisitos//////////////////
            if (Matriz1 == null)
            {
                MessageBox.Show("erro, mude os valores");
            }

            //////////////fecha_requisitos//////////////////
            #endregion
            #region Det
            float[,] valoresMatriz2 = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            float n = 0;
            for (int x = 0; x < Matriz1.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz1.GetLength(1); y++)
                {

                    float.TryParse(Matriz1[x, y].Text, out n);
                    valoresMatriz2[x, y] = n;
                    //tempResultante[x, y] = Convert.ToInt32(Matriz1[x, y].Text);
                }
            }
            if (valoresMatriz2.GetLength(0) == 1 && valoresMatriz2.GetLength(1) == 1)
            {
                determinante = n;
                MessageBox.Show("O determinante é:" + determinante, "Determinante...");
            }
            else if (valoresMatriz2.GetLength(0) == 2 && valoresMatriz2.GetLength(1) == 2)
            {
                determinante = calculos.Det2(valoresMatriz2);
                MessageBox.Show("O determinante é:" + determinante, "Determinante...");
            }
            else if (valoresMatriz2.GetLength(0) == 3 && valoresMatriz2.GetLength(1) == 3)
            {
                determinante = calculos.determinantes3x3(valoresMatriz2);
                MessageBox.Show("O determinante é:" + determinante, "Determinante...");
            }
            else
            {

                MessageBox.Show("erro");
            }
            #endregion
        }

        private void button11_Click(object sender, EventArgs e)
        {
            #region Resquistos
            //////////////requisitos//////////////////
            if (Matriz2 == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }
            #endregion
            #region Det
            float[,] valoresMatriz2 = new float[Matriz2.GetLength(0), Matriz2.GetLength(1)];
            float n = 0;
            for (int x = 0; x < Matriz2.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz2.GetLength(1); y++)
                {

                    float.TryParse(Matriz2[x, y].Text, out n);
                    valoresMatriz2[x, y] = n;
                    //tempResultante[x, y] = Convert.ToInt32(Matriz1[x, y].Text);
                }
            }
            if (valoresMatriz2.GetLength(0) == 1 && valoresMatriz2.GetLength(1) == 1)
            {
                determinante = n;
                MessageBox.Show("O determinante é:" + determinante, "Determinante...");
            }
            else if (valoresMatriz2.GetLength(0) == 2 && valoresMatriz2.GetLength(1) == 2)
            {
                determinante = calculos.Det2(valoresMatriz2);
                MessageBox.Show("O determinante é:" + determinante, "Determinante...");
            }
            else if (valoresMatriz2.GetLength(0) == 3 && valoresMatriz2.GetLength(1) == 3)
            {
                determinante = calculos.determinantes3x3(valoresMatriz2);
                MessageBox.Show("O determinante é:" + determinante, "Determinante...");
            }
            else {

                MessageBox.Show("erro");
            }
            #endregion
        }

        private void button15_Click(object sender, EventArgs e)
        {
            #region Resquistos
            //////////////requisitos//////////////////
            if (MatrizCalculada == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }

            //////////////fecha_requisitos//////////////////
            #endregion
            #region Det
            float[,] valoresMatriz2 = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            float n = 0;
            for (int x = 0; x < Matriz1.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz1.GetLength(1); y++)
                {

                    float.TryParse(Matriz1[x, y].Text, out n);
                    valoresMatriz2[x, y] = n;
                    //tempResultante[x, y] = Convert.ToInt32(Matriz1[x, y].Text);
                }
            }
            if (valoresMatriz2.GetLength(0) == 1 && valoresMatriz2.GetLength(1) == 1)
            {
                determinante = n;
                MessageBox.Show("O determinante é:" + determinante, "Determinante...");
            }
            else if (valoresMatriz2.GetLength(0) == 2 && valoresMatriz2.GetLength(1) == 2)
            {
                determinante = calculos.Det2(valoresMatriz2);
                MessageBox.Show("O determinante é:" + determinante, "Determinante...");
            }
            else if (valoresMatriz2.GetLength(0) == 3 && valoresMatriz2.GetLength(1) == 3)
            {
                determinante = calculos.determinantes3x3(valoresMatriz2);
                MessageBox.Show("O determinante é:" + determinante, "Determinante...");
            }
            else
            {

                MessageBox.Show("erro");
            }
            #endregion
        }

        private void button2_Click(object sender, EventArgs e)
        {
            #region Requistos
            //////////////requisitos//////////////////
            float[,] sizeMatriz = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            float[,] sizeMatriz2 = new float[Matriz2.GetLength(0), Matriz2.GetLength(1)];

            if (sizeMatriz.GetLength(0) != sizeMatriz2.GetLength(0) || sizeMatriz.GetLength(1) != sizeMatriz2.GetLength(1) || Matriz1 == null || Matriz2 == null)
            {
                MessageBox.Show("só se pode diminuir matrizes de mesma ordem, tente novamente");
                return;
            }
            //////////////fecha_requisitos//////////////////
            #endregion
            #region Estrutura_Subtrair
            for (int x = 0; x < Matriz1.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz1.GetLength(1); y++)
                {
                    float h = 0;
                    float.TryParse(Matriz1[x, y].Text, out h);
                    sizeMatriz[x, y] = h;
                    //tempMatriz1[x, y] = Convert.ToInt32(Matriz1[x, y].Text);
                }
            }

            for (int x = 0; x < Matriz2.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz2.GetLength(1); y++)
                {
                    float b = 0;
                    float.TryParse(Matriz2[x, y].Text, out b);
                    sizeMatriz2[x, y] = b;
                    //tempMatriz2[x, y] = Convert.ToInt32(Matriz2[x, y].Text);
                }
            }

            float[,] tempMatrizCalculada = calculos.Subtrair(sizeMatriz, sizeMatriz2);
            MatrizCalculada = new TextBox[tempMatrizCalculada.GetLength(0), tempMatrizCalculada.GetLength(1)];
            int TamanhoText = GMC.Width / MatrizCalculada.GetLength(1);
            GMC.Controls.Clear();
            for (int x = 0; x < MatrizCalculada.GetLength(0); x++)
            {
                for (int y = 0; y < MatrizCalculada.GetLength(1); y++)
                {
                    MatrizCalculada[x, y] = new TextBox();
                    MatrizCalculada[x, y].Text = tempMatrizCalculada[x, y].ToString();
                    MatrizCalculada[x, y].Top = (x * MatrizCalculada[x, y].Height) + 20;
                    MatrizCalculada[x, y].Left = y * TamanhoText + 6;
                    MatrizCalculada[x, y].Width = TamanhoText;
                    GMC.Controls.Add(MatrizCalculada[x, y]);
                }
            }

            #endregion
        }
        private void button3_Click(object sender, EventArgs e)
        {
            #region Requisitos
            //////////////requisitos//////////////////
            float[,] sizeMatriz = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            float[,] sizeMatriz2 = new float[Matriz2.GetLength(0), Matriz2.GetLength(1)];

            if (sizeMatriz.GetLength(1) != sizeMatriz2.GetLength(0) || Matriz1 == null || Matriz2 == null)
            {
                MessageBox.Show("só se pode fazer multiplicação matricial quando a o número de colunas da 1° Matriz for igual ao n° de linhas da 2°, tente novamente");
                return;
            }
            //////////////fecha_requisitos//////////////////
            #endregion 
            #region Estrutura_Multiplicação

            for (int x = 0; x < Matriz1.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz1.GetLength(1); y++)
                {
                    float h = 0;
                    float.TryParse(Matriz1[x, y].Text, out h);
                    sizeMatriz[x, y] = h;
                    //tempMatriz1[x, y] = Convert.ToInt32(Matriz1[x, y].Text);
                }
            }
            for (int x = 0; x < Matriz2.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz2.GetLength(1); y++)
                {
                    float n = 0;
                    float.TryParse(Matriz2[x, y].Text, out n);
                    sizeMatriz2[x, y] = n;
                    //tempMatriz2[x, y] = Convert.ToInt32(Matriz2[x, y].Text);
                }
            }

            float[,] tempMatrizCalculada = calculos.Multiplicar(sizeMatriz, sizeMatriz2);
            MatrizCalculada = new TextBox[tempMatrizCalculada.GetLength(0), tempMatrizCalculada.GetLength(1)];
            int TamanhoText = GMC.Width / MatrizCalculada.GetLength(1);
            GMC.Controls.Clear();
            for (int x = 0; x < MatrizCalculada.GetLength(0); x++)
            {
                for (int y = 0; y < MatrizCalculada.GetLength(1); y++)
                {
                    MatrizCalculada[x, y] = new TextBox();
                    MatrizCalculada[x, y].Text = tempMatrizCalculada[x, y].ToString();
                    MatrizCalculada[x, y].Top = (x * MatrizCalculada[x, y].Height) + 20;
                    MatrizCalculada[x, y].Left = y * TamanhoText + 6;
                    MatrizCalculada[x, y].Width = TamanhoText;
                    GMC.Controls.Add(MatrizCalculada[x, y]);
                }
            }

            #endregion
        }

        private void button5_Click(object sender, EventArgs e)
        {
            #region Requisitos
            //////////////requisitos//////////////////
            if (Matriz1 == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }

            //////////////fecha_requisitos//////////////////
            #endregion
            #region estrutura_transposta
            //////////////começa_operações//////////////////

            float c = 0;
            float[,] valoresMatriz1 = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            for (int a = 0; a < Matriz1.GetLength(0); a++)
            {
                for (int b = 0; b < Matriz1.GetLength(1); b++)
                {
                    float.TryParse(Matriz1[a, b].Text, out c);
                    valoresMatriz1[a, b] = c;
                }
            }
            float[,] matrizR = calculos.Transposta(valoresMatriz1);
            int TamanhoText = GM1.Width / Matriz1.GetLength(0);
            Matriz1 = new TextBox[matrizR.GetLength(0), matrizR.GetLength(1)];
            GM1.Controls.Clear();
            for (int x = 0; x < Matriz1.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz1.GetLength(1); y++)
                {
                    Matriz1[x, y] = new TextBox();
                    Matriz1[x, y].Text = matrizR[x, y].ToString();
                    Matriz1[x, y].Top = (x * Matriz1[x, y].Height) + 20;
                    Matriz1[x, y].Left = y * TamanhoText + 6;
                    Matriz1[x, y].Width = TamanhoText;
                    GM1.Controls.Add(Matriz1[x, y]);
                }
            }
            #endregion
        }
        private void button6_Click(object sender, EventArgs e)
        {
            #region Requisitos
            //////////////requisitos//////////////////
            if (Matriz1 == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }

            //////////////fecha_requisitos//////////////////
            #endregion
            #region Estrutura_Oposta
            //////////////operações//////////////////
            float c = 0;
            float[,] valoresMatriz1 = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            for (int a = 0; a < Matriz1.GetLength(0); a++)
            {
                for (int b = 0; b < Matriz1.GetLength(1); b++)
                {

                    float.TryParse(Matriz1[a, b].Text, out c);
                    valoresMatriz1[a, b] = c;
                }
            }
            float[,] matrizR = calculos.Oposta(valoresMatriz1);

            int TamanhoText = GM1.Width / Matriz1.GetLength(1);
            for (int x = 0; x < Matriz1.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz1.GetLength(1); y++)
                {
                    Matriz1[x, y].Text = matrizR[x, y].ToString();
                }
            }
            //////////////fecha_operações//////////////////
            #endregion
        }

        private void button7_Click(object sender, EventArgs e)
        {
            #region Requisitos
            //////////////requisitos//////////////////
            if (Matriz1 == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }
            //////////////fecha_requisitos//////////////////
            #endregion
           /*#region Inversa
            float[,] tempResultante = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            float[,] matrizAdjunta = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            float[,] matrizCofatora = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            float determinante = 0;
            if (tempResultante.GetLength(0) != 2 || tempResultante.GetLength(1) != 2)
            {
                if (tempResultante.GetLength(0) != 3 || tempResultante.GetLength(1) != 3)
                {
                    MessageBox.Show("Matriz invalida !", "Error - Matriz");
                    return;
                }
            }
            for (int x = 0; x < Matriz1.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz1.GetLength(1); y++)
                {
                    float n = 0;
                    float.TryParse(Matriz1[x, y].Text, out n);
                    tempResultante[x, y] = n;
                }
            }
            /*Matriz Adjunta(A) = Matriz Transposta(Matriz dos cofatores(A))
            Matriz Inversa(A) = (1/ Determinante(A)) * Matriz Adjunta(A)
            if (tempResultante.GetLength(0) == 2 && tempResultante.GetLength(1) == 2)
            {
                matrizCofatora = calculos.GerarCofatora2x2(tempResultante);
                matrizAdjunta = calculos.GerarTransposta(matrizCofatora);
                determinante = calculos.Det2(tempResultante);
            }
            else if (tempResultante.GetLength(0) == 3 && tempResultante.GetLength(1) == 3)
            {
                matrizCofatora = calculos.GerarCofatora3x3(tempResultante);
                matrizAdjunta = calculos.GerarTransposta(matrizCofatora);
                determinante = calculos.GerarDeterminante3x3(tempResultante);
            }
            else
            {
                MessageBox.Show("Matriz invalida !", "Error - Matriz");
                return;
            }
            if (determinante == 0)
            {
                MessageBox.Show("Matriz invalida, determinante igual a 0 !", "Error - Matriz");
                return;
            }
            float[,] tempMatrizResultante = CalculosMatrizes.GerarInversa(determinante, matrizAdjunta);
            int TamanhoText = groupBoxMatriz1.Width / Matriz1.GetLength(1);
            for (int x = 0; x < Matriz1.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz1.GetLength(1); y++)
                {
                    Matriz1[x, y].Text = tempMatrizResultante[x, y].ToString();
                }
            }
            #endregion 
            */

        }

        private void button16_Click(object sender, EventArgs e)
        {
            #region Requisitos
            //////////////requisitos//////////////////
            if (Matriz1 == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }

            //////////////fecha_requisitos//////////////////
            #endregion
        }

        private void button10_Click(object sender, EventArgs e)
        {
            #region Requisitos
            //////////////requisitos//////////////////
            if (Matriz2 == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }

            //////////////fecha_requisitos//////////////////
            #endregion
            #region Estrutura_transposta
            float c = 0;
            float[,] valoresMatriz2 = new float[Matriz2.GetLength(0), Matriz2.GetLength(1)];
            for (int a = 0; a < Matriz2.GetLength(0); a++)
            {
                for (int b = 0; b < Matriz2.GetLength(1); b++)
                {
                    float.TryParse(Matriz2[a, b].Text, out c);
                    valoresMatriz2[a, b] = c;
                }
            }
            float[,] matrizR = calculos.Transposta(valoresMatriz2);
            int TamanhoText = GM2.Width / Matriz2.GetLength(0);
            Matriz2 = new TextBox[matrizR.GetLength(0), matrizR.GetLength(1)];
            GM2.Controls.Clear();
            for (int x = 0; x < Matriz2.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz2.GetLength(1); y++)
                {
                    Matriz2[x, y] = new TextBox();
                    Matriz2[x, y].Text = matrizR[x, y].ToString();
                    Matriz2[x, y].Top = (x * Matriz2[x, y].Height) + 20;
                    Matriz2[x, y].Left = y * TamanhoText + 6;
                    Matriz2[x, y].Width = TamanhoText;
                    GM2.Controls.Add(Matriz2[x, y]);
                }
            }
            #endregion
        }

        private void button9_Click(object sender, EventArgs e)
        {
            #region Requisitos
            //////////////requisitos//////////////////
            if (Matriz2 == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }

            //////////////fecha_requisitos//////////////////
            #endregion
            #region Estrutura_oposta
            float c = 0;
            float[,] valoresMatriz2 = new float[Matriz2.GetLength(0), Matriz2.GetLength(1)];
            for (int a = 0; a < Matriz2.GetLength(0); a++)
            {
                for (int b = 0; b < Matriz2.GetLength(1); b++)
                {

                    float.TryParse(Matriz2[a, b].Text, out c);
                    valoresMatriz2[a, b] = c;
                }
            }
            float[,] matrizR = calculos.Oposta(valoresMatriz2);

            int TamanhoText = GM2.Width / Matriz2.GetLength(1);
            for (int x = 0; x < Matriz2.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz2.GetLength(1); y++)
                {
                    Matriz2[x, y].Text = matrizR[x, y].ToString();
                }
            }
            #endregion
        }

        private void button8_Click(object sender, EventArgs e)
        {
            #region Resquistos
            //////////////requisitos//////////////////
            if (Matriz2 == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }

            //////////////fecha_requisitos//////////////////
            #endregion
        }

        private void button17_Click(object sender, EventArgs e)
        {
            #region Resquistos
            //////////////requisitos//////////////////
            if (Matriz2 == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }

            //////////////fecha_requisitos//////////////////
            #endregion
        }

        private void button14_Click(object sender, EventArgs e)
        {
            #region Resquistos
            //////////////requisitos//////////////////
            if (MatrizCalculada == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }

            //////////////fecha_requisitos//////////////////
            #endregion
        }

        private void button13_Click(object sender, EventArgs e)
        {
            #region Resquistos
            //////////////requisitos//////////////////
            if (MatrizCalculada == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }

            //////////////fecha_requisitos//////////////////
            #endregion
        }

        private void GM1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            #region Requisitos
            //////////////requisitos//////////////////
            if (Matriz1 == null)
            {
                MessageBox.Show("viado");
                return;
            }

            float[,] sizeMatriz = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            float[,] sizeMatriz2 = new float[Matriz2.GetLength(0), Matriz2.GetLength(1)];

            if (sizeMatriz.GetLength(0) != sizeMatriz2.GetLength(0) || sizeMatriz.GetLength(1) != sizeMatriz2.GetLength(1) || Matriz1 == null || Matriz2 == null)
            {
                MessageBox.Show("só se pode somar matrizes de mesma ordem, tente novamente");
                return;
            }
            //////////////fecha_requisitos//////////////////
            #endregion
            #region Estrutura_Soma

            for (int x = 0; x < Matriz1.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz1.GetLength(1); y++)
                {
                    float h = 0;
                    float.TryParse(Matriz1[x, y].Text, out h);
                    sizeMatriz[x, y] = h;
                    //tempMatriz1[x, y] = Convert.ToInt32(Matriz1[x, y].Text);
                }
            }

            for (int x = 0; x < Matriz2.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz2.GetLength(1); y++)
                {
                    float b = 0;
                    float.TryParse(Matriz2[x, y].Text, out b);
                    sizeMatriz2[x, y] = b;
                    //tempMatriz2[x, y] = Convert.ToInt32(Matriz2[x, y].Text);
                }
            }

            float[,] tempMatrizCalculada = calculos.Somar(sizeMatriz, sizeMatriz2);
            MatrizCalculada = new TextBox[tempMatrizCalculada.GetLength(0), tempMatrizCalculada.GetLength(1)];
            int TamanhoText = GMC.Width / MatrizCalculada.GetLength(1);
            GMC.Controls.Clear();
            for (int x = 0; x < MatrizCalculada.GetLength(0); x++)
            {
                for (int y = 0; y < MatrizCalculada.GetLength(1); y++)
                {
                    MatrizCalculada[x, y] = new TextBox();
                    MatrizCalculada[x, y].Text = tempMatrizCalculada[x, y].ToString();
                    MatrizCalculada[x, y].Top = (x * MatrizCalculada[x, y].Height) + 20;
                    MatrizCalculada[x, y].Left = y * TamanhoText + 6;
                    MatrizCalculada[x, y].Width = TamanhoText;
                    GMC.Controls.Add(MatrizCalculada[x, y]);
                }
            }
            #endregion
        }

        private void button12_Click(object sender, EventArgs e)
        {
            #region Resquistos
            //////////////requisitos//////////////////
            if (MatrizCalculada == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }

            //////////////fecha_requisitos//////////////////
            #endregion
        }

        private void button18_Click(object sender, EventArgs e)
        {
            #region Resquistos
            //////////////requisitos//////////////////
            if (MatrizCalculada == null)
            {
                MessageBox.Show("erro, mude os valores");
                return;
            }

            //////////////fecha_requisitos//////////////////
            #endregion
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialog = MessageBox.Show("vc quer sair?", "Sair", MessageBoxButtons.YesNo);

            if (dialog == DialogResult.Yes)
            {
                DialogResult dialog2 = MessageBox.Show("vc quer realmente sair?", "Sair", MessageBoxButtons.YesNo);
                if (dialog2 == DialogResult.Yes)
                {
                    Application.Exit();
                }
                else if (dialog2 == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
            else if (dialog == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("vc quer sair?", "Sair", MessageBoxButtons.YesNo);

            if (dialog == DialogResult.Yes)
            {
                DialogResult dialog2 = MessageBox.Show("vc quer realmente sair?", "Sair", MessageBoxButtons.YesNo);
                if (dialog2 == DialogResult.Yes)
                {
                    Application.Exit();
                }
                else if (dialog2 == DialogResult.No)
                {
                    return;
                }
            }
            else if (dialog == DialogResult.No)
            {
                return;
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
            return;
        }

        private void button21_Click(object sender, EventArgs e)
        {
            if (Matriz1 == null)
            {
                MessageBox.Show("winston");
            }
            float[,] valoresMatriz1 = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            float n = 0;
            for (int x = 0; x < Matriz1.GetLength(0); x++)
            {
                for (int y = 0; y < Matriz1.GetLength(0); y++)
                {
                    //  float.TryParse(escalar[].Text);
                    float.TryParse(Matriz1[x, y].Text, out n);
                    valoresMatriz1[x, y] = n;
                }
            }
            int valorescalarAux;
            valorescalarAux = int.Parse(maskedTextBox1.Text);
            float[,] valoresescalar1 = calculos.Escalar(valoresMatriz1, valorescalarAux);
            MatrizCalculada = new TextBox[valoresescalar1.GetLength(0), valoresescalar1.GetLength(1)];
            int TamanhoText = GMC.Width / MatrizCalculada.GetLength(1);
            GMC.Controls.Clear();
            for (int x = 0; x < MatrizCalculada.GetLength(0); x++)
            {
                for (int y = 0; y < MatrizCalculada.GetLength(1); y++)
                {
                    MatrizCalculada[x, y] = new TextBox();
                    MatrizCalculada[x, y].Text = valoresescalar1[x, y].ToString();
                    MatrizCalculada[x, y].Top = (x * MatrizCalculada[x, y].Height) + 20;
                    MatrizCalculada[x, y].Left = y * TamanhoText + 6;
                    MatrizCalculada[x, y].Width = TamanhoText;
                    GMC.Controls.Add(MatrizCalculada[x, y]);
                }
            }
            /* if(Matriz1.GetLength(0) == 1 && Matriz1.GetLength(1) == 1){
                 valorescalar = n * 5;
                 MessageBox.Show("O escalar é:" + valorescalar, "Determinante..."); ;
             }*/


        }

        private void button26_Click(object sender, EventArgs e)
        {
            chart1.Series.Clear();
        }

        private void button25_Click(object sender, EventArgs e)
        {

            float[,] valoresMatriz1 = new float[Matriz1.GetLength(0), Matriz1.GetLength(1)];
            float n = 0;
           
            float[,] valores;

            float[] numeros = new float[4];
            for (int x = 0; x < Matriz1.GetLength(0); x++)
            {
               
               
                for (int y = 0; y < Matriz1.GetLength(1); y++)
                {
                    //  float.TryParse(escalar[].Text);
                    float.TryParse(Matriz1[x, y].Text, out n);
                    valores = new float[x, y];
                    valoresMatriz1[x, y] = n;
                    numeros[0] = valoresMatriz1[0,y];
                    numeros[1] = valoresMatriz1[x, 0];
                    numeros[2] = valoresMatriz1[0, y]; ;
                    numeros[3] = valoresMatriz1[x, 0];
                    chart1.Series["test1"].Points.AddXY(numeros[1], numeros[3]);

                    //
                    MessageBox.Show("número = " + numeros[1] + " " + numeros[2]);
                }
            }

            //CreateChart();
            //  chart1.Series["test1"].Points.AddXY(valores[x,y]);

            chart1.Series["test1"].Points.AddXY(numeros[1], numeros[3]);

            chart1.Series["test1"].ChartType =
                                SeriesChartType.FastLine;
            chart1.Series["test1"].Color = Color.Red;
        }

        private void button22_Click(object sender, EventArgs e)
        {
            #region Requisitos

            if (Matriz2 == null)
            {
                MessageBox.Show("winston");
            }

            #endregion
            float[,] valoresMatriz2 = new float[Matriz2.GetLength(0), Matriz2.GetLength(1)];
            float n = 0;
            for (int x = 0; x < Matriz2.GetLongLength(0); x++)
            {
                for (int y = 0; y < Matriz2.GetLongLength(0); y++)
                {
                    //  float.TryParse(escalar[].Text);
                    float.TryParse(Matriz2[x, y].Text, out n);
                    valoresMatriz2[x, y] = n;
                }
            }
            int valorescalarAux;
            valorescalarAux = int.Parse(maskedTextBox2.Text);
            float[,] valoresescalar1 = calculos.Escalar(valoresMatriz2, valorescalarAux);
            MatrizCalculada = new TextBox[valoresescalar1.GetLongLength(0), valoresescalar1.GetLongLength(1)];
            int TamanhoText = GMC.Width / MatrizCalculada.GetLength(1);
            GMC.Controls.Clear();
            for (int x = 0; x < MatrizCalculada.GetLongLength(0); x++)
            {
                for (int y = 0; y < MatrizCalculada.GetLongLength(1); y++)
                {
                    MatrizCalculada[x, y] = new TextBox();
                    MatrizCalculada[x, y].Text = valoresescalar1[x, y].ToString();
                    MatrizCalculada[x, y].Top = (x * MatrizCalculada[x, y].Height) + 20;
                    MatrizCalculada[x, y].Left = y * TamanhoText + 6;
                    MatrizCalculada[x, y].Width = TamanhoText;
                    GMC.Controls.Add(MatrizCalculada[x, y]);
                }
            }
            /* if(Matriz1.GetLength(0) == 1 && Matriz1.GetLength(1) == 1){
                 valorescalar = n * 5;
                 MessageBox.Show("O escalar é:" + valorescalar, "Determinante..."); ;
             }*/


        }

        /*  private void chart1_Click(object sender, EventArgs e)
          {
              this.chart1.Series["Matriz1"].Points.AddXY("Linha", 2);
              this.chart1.Series["Matriz1"].Points.AddXY("Max", Matriz1.GetLength(0));
              this.chart1.Series["Matriz1"].Points.AddXY("Linha", 2);
              this.chart1.Series["Matriz1"].Points.AddXY("Min", Matriz1.GetLength(1));
              this.chart1.Series["Matriz1"].Points.AddXY("Coluna", 2);
              this.chart1.Series["Matriz1"].Points.AddXY("Min", 2);








          }*/

      
    }
}

